import java.sql.*;
import java.util.*;
import java.util.Map.Entry;

public class searchUser {

	public static void main(String[] args) throws ClassNotFoundException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost/BuddyBuddy";
		String user = "root", passwd = "12345";
		Scanner scan = new Scanner(System.in);

		try (Connection connection = DriverManager.getConnection(url, user, passwd)) {
			int ID = 1; // ������ �����, �α��ε� ���� ID
			Boolean search = true;
			while (search == true) { // search ��ư�� ���� true�� ����� ��
				String target_id = null; // gui�� ���� ��� ID �Է�
				Statement stmt = connection.createStatement();
				String sql = "select * from user";
				ResultSet rs = stmt.executeQuery(sql);
				target_id = scan.nextLine();
				if(target_id != null) {
					while(rs.next()) {
						if(rs.getString(ID).contains(target_id)) {
							System.out.println(rs.getString(2));
						}
					}
				}
			}
			search = false; // â�� �� ��
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}